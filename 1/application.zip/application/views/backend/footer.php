</div>
<div class="logo-holder no-pad-top">
  <img src="<?php echo base_url('assets/img/logo-brand.png')?>" alt="Happyness Quotient">
  <div class="clearfix"></div>
</div>
</main>

</body>
<script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
</script>
</html>
