
    <div class="">
        <div class="">
          <h5 class="padleft">Schedule</h5>

            <div class="row">
               <!--               First pillar-->
                <div class="col s6 ">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[0]->name?></p>
                                </div>
                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>1. <span><?php echo $question[0]->text?></span></p>
                                        </div>

                                    </div>
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>2. <span><?php echo $question[1]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>3. <span><?php echo $question[2]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>4. <span><?php echo $question[3]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                </div>

<!--               SEcond pillar-->

                <div class="col s6 ">
                    <div class="">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[1]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>5. <span><?php echo $question[4]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>6. <span><?php echo $question[5]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>7. <span><?php echo $question[6]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>8. <span><?php echo $question[7]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
              </div>

<!--                    third pillar-->
<div class="row">
                      <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[2]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>9. <span><?php echo $question[8]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>10. <span><?php echo $question[9]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>11. <span><?php echo $question[10]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>12. <span><?php echo $question[11]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

<!--                      fourth pillar-->
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[3]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>13. <span><?php echo $question[12]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>14. <span><?php echo $question[13]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>15. <span><?php echo $question[14]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>16. <span><?php echo $question[15]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
</div>

                      <!--                      fifth pillar-->
                      <div class="row">
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[4]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>17. <span><?php echo $question[16]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>18. <span><?php echo $question[17]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>19. <span><?php echo $question[18]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>20. <span><?php echo $question[19]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                      <!--                      Sixth pillar-->
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[5]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>21. <span><?php echo $question[20]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>22. <span><?php echo $question[21]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>23. <span><?php echo $question[22]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>24. <span><?php echo $question[23]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
              </div>


                               <!--                      Seventh pillar-->
                               <div class="row">
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[6]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>25. <span><?php echo $question[24]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>26. <span><?php echo $question[25]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>27. <span><?php echo $question[26]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>28. <span><?php echo $question[27]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>


                                        <!--                      Eight pillar-->
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[7]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>29. <span><?php echo $question[28]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>30. <span><?php echo $question[29]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>31. <span><?php echo $question[30]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>32. <span><?php echo $question[31]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
</div>

                                                    <!--                      Nine pillar-->
<div class="row">
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[8]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>33. <span><?php echo $question[32]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>34. <span><?php echo $question[33]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>35. <span><?php echo $question[34]->text?></span></p>
                                        </div>

                                    </div>
<!--
                                    <div class="col s3">
                                        <ul class="text-center matop">
                                            <li>15, jan 2015</li>
                                            <li class="box-tp">Customize</li>
                                        </ul>
                                    </div>
-->
                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>36. <span><?php echo $question[35]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                                                       <!--                      Ten pillar-->
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[9]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>37. <span><?php echo $question[36]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>38. <span><?php echo $question[37]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>39. <span><?php echo $question[38]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>40. <span><?php echo $question[39]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                </div>

                <!-- // two extra question -->
                <div class="p15">

                    <div class="panel panel-primary">
                        <div class="panel-body">
                            <div class="row marbotm">
                    <div class="col s6">
                        <div class="text-p ">
                            <p>41. <span><?php echo $question[40]->text?></span></p>
                        </div>

                    </div>
                    <div class="col s6">
                        <div class="text-p ">
                            <p>42. <span><?php echo $question[41]->text?></span></p>
                        </div>

                    </div>

                </div>
                </div>
                </div>
                </div>
                <!-- // two extra question -->
                          <?php if($checkpackage==4){?>
                                  <!--                      Eleven pillar-->
                       <div class="col s6 ">
                    <div class="p15">

                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="pull-left  displ">
                                    <p class="panel-title"><?php echo $pillar[10]->name?></p>
                                </div>


                            </div>

                            <div class="panel-body">
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>41. <span><?php echo $question[42]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>42. <span><?php echo $question[43]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>43. <span><?php echo $question[44]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                                <div class="row marbotm">
                                    <div class="col s9">
                                        <div class="text-p ">
                                            <p>44. <span><?php echo $question[45]->text?></span></p>
                                        </div>

                                    </div>

                                </div>
                            </div>




                        </div>

                    </div>
                </div>
                <?php }?>
                <a href="<?php echo site_url('site/sendMailToEachUser'); ?>" class="btn btn-secondary waves-effect waves-light  red">Send</a>
        </div>
    </div>
