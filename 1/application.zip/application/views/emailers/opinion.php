<html>

<body style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#000;">
  <section style="width: 600px; margin:0 auto;">
    <div style="border:0;">
      <div style="text-align:center;">
        <img src="http://wohlig.co.in/hqemailerimg/18.png" alt="" width="100%;">
      </div>
      <div style="padding: 0px 25px 0px;">
        <div style="padding:10px 0">
          <p style="margin:15px 0px;">Dear Colleagues,
          </p>
          <p style="margin:15px 0px;">In this organization, we believe that every opinion matters. Every voice deserves a platform and that's what we are here to provide.</p>
          <dpiv style="margin:0 0 15px 0;">
            In order for your voice to be heard, here's a quick survey that we'd like you to take part in
            <!-- insert Link --><a href="<?php echo $link;?>" target="_blank">Click here to start.</a>
            <!--End Link -->
        </div>

        <div style="margin:0 0 15px 0;">
          Quick tip: Pick the answer you believe in. All responses are kept confidential.
        </div>
        <p style="margin:0 0 15px 0;">
          Please feel free to reach out to the HR Team in case of any queries. We are happy to help.
        </p>
        <p style="margin:0 0 15px 0;">
          Team HR</p>
      </div>
    </div>
    <div style="padding-bottom:10px">
      <img src="http://wohlig.co.in/hqemailerimg/15.png" alt="" width="100%;">
    </div>
    </div>
  </section>
</body>

</html>
