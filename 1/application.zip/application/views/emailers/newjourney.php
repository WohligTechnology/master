<html>

<body style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#000;">
  <section style="width: 600px; margin:0 auto;">
    <div style="border:0;">
      <div style="text-align:center;">
        <img src="http://wohlig.co.in/hqemailerimg/2.png" alt="" width="100%;">
      </div>
      <div style="padding: 0px 25px 0px;">
        <div style="padding:10px 0">
          <p style="margin:15px 0px;"> Hey Happyness Torch-bearer,
          </p>
          <p style="margin:0 0 15px 0;">
            We hope you enjoyed measuring Happyness at Work in your company! </p>
          <p style="margin:0 0 15px 0;">
            Because of the package that you have chosen, your Happyness Quotient journey does not end here.
          </p>
          <p style="margin:0 0 15px 0;">
            To understand what your employees are thinking about other aspects of life at work,

            <!-- insert Link -->
            <a href="<?php echo $link;?>" target="_blank">create a mini survey right here!</a>
            <!--End Link -->

          </p>

          <p style="margin:0 0 15px 0;">
            You can create as many mini surveys as you like.
          </p>
          <p style="margin:0 0 15px 0;">
            Happy to help!</p>
          <p style="margin:0 0 15px 0;">
            Regards, <br>
            Team Never Grow Up
          </p>
          <hr style="border:1px dashed #000;margin: 28px 151px 0 0;">
          <p style="padding: 6px 0;margin:0px;">
            Note: This is a system generated email, do not respond to this.
          </p>
        </div>
      </div>
      <div style="padding-bottom:10px">
        <img src="http://wohlig.co.in/hqemailerimg/14.png" alt="" width="100%;">
      </div>
    </div>
  </section>
</body>

</html>
