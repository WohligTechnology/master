<html>

<body style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#000;">
  <section style="width: 600px; margin:0 auto;">
    <div style="border:0;">
      <div style="text-align:center;">
        <img src="http://wohlig.co.in/hqemailerimg/1.png" alt="" width="100%;">
      </div>
      <div style="padding: 0px 25px 0px;">
        <div style="padding:10px 0">
          <p style="margin:15px 0px;"> Hey Happyness Torch-bearer,
          </p>
          <p style="margin:0 0 15px 0;">
            Looks like your password to access Happyness Quotient has been changed. </p>
          <p style="margin:0 0 15px 0;">
            If you are not aware of how this has happened, let us know right away.
          </p>
          <p style="margin:0 0 15px 0;">
            Happy to help!</p>
          <p style="margin:0 0 15px 0;">
            <span>Regards, <br>
            Team Never Grow Up</span>
          </p>
          <hr style="border:1px dashed #000;margin: 28px 151px 0 0;">
          <p style="padding: 6px 0;margin:0px;">
            Note: This is a system generated email, do not respond to this.
          </p>
        </div>
      </div>
      <div style="padding-bottom:10px">
        <img src="http://wohlig.co.in/hqemailerimg/15.png" alt="" width="100%;">
      </div>
    </div>
  </section>
</body>

</html>
