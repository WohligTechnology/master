$( document ).ready(function() {
    $("[name=range]").on("change", function() {
    $("[for=range]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangeone]").on("change", function() {
    $("[for=rangeone]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangetwo]").on("change", function() {
    $("[for=rangetwo]").val(this.value +"%" );
    }).trigger("change"); 

    $("[name=rangethree]").on("change", function() {
    $("[for=rangethree]").val(this.value +"%" );
    }).trigger("change"); 

    $("[name=rangefour]").on("change", function() {
    $("[for=rangefour]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangefive]").on("change", function() {
    $("[for=rangefive]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangesix]").on("change", function() {
    $("[for=rangesix]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangeseven]").on("change", function() {
    $("[for=rangeseven]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangeeight]").on("change", function() {
    $("[for=rangeeight]").val(this.value +"%" );
    }).trigger("change");

    $("[name=rangenine]").on("change", function() {
    $("[for=rangenine]").val(this.value +"%" );
    }).trigger("change");
      $("[name=rangeeleven]").on("change", function() {
            $("[for=rangeeleven]").val(this.value + "%");
        }).trigger("change");
    });